package com.delpech.pomparent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PomParentApplication {

	public static void main(String[] args) {
		SpringApplication.run(PomParentApplication.class, args);
	}

}
