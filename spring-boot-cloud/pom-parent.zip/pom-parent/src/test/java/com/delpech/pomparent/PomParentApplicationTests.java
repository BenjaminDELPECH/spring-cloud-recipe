package com.delpech.pomparent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PomParentApplicationTests {

	@Test
	void contextLoads() {
	}

}
