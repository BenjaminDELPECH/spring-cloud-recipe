package com.edelpech.sharedlibrarystarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SharedLibraryStarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SharedLibraryStarterApplication.class, args);
	}

}
